const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();

const PASSWORD_PEPPER = defineSecret("PASSWORD_PEPPER");

function normalizeUsername(raw) {
  return String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9._-]/g, "");
}

function passwordFingerprint(password, pepper) {
  return crypto
    .createHmac("sha256", pepper)
    .update(String(password))
    .digest("hex");
}

exports.registerUsername = onCall(
  { secrets: [PASSWORD_PEPPER] },
  async (request) => {
    const username = normalizeUsername(request.data?.username);
    const displayName = String(request.data?.displayName || "").trim();
    const password = String(request.data?.password || "");

    if (!username || !displayName) {
      throw new HttpsError("invalid-argument", "USERNAME_REQUIRED");
    }
    if (password.length < 4) {
      throw new HttpsError("invalid-argument", "PASSWORD_TOO_SHORT");
    }

    const internalEmail = `${username}@nicechart.local`;
    const db = admin.firestore();

    // The fingerprint is deterministic only inside this trusted server because
    // it is keyed with PASSWORD_PEPPER. Raw passwords are never stored.
    const fingerprint = passwordFingerprint(password, PASSWORD_PEPPER.value());
    const passwordRef = db.collection("passwordFingerprints").doc(fingerprint);
    const usernameRef = db.collection("usernames").doc(username);

    let createdUid = null;

    try {
      await db.runTransaction(async (tx) => {
        const [passwordSnap, usernameSnap] = await Promise.all([
          tx.get(passwordRef),
          tx.get(usernameRef)
        ]);

        if (passwordSnap.exists) {
          throw new HttpsError("already-exists", "PASSWORD_NOT_ALLOWED");
        }
        if (usernameSnap.exists) {
          throw new HttpsError("already-exists", "USERNAME_ALREADY_USED");
        }

        // Reserve both values atomically before creating Auth account.
        tx.create(passwordRef, {
          reserved: true,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
        tx.create(usernameRef, {
          reserved: true,
          displayName,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
      });

      const user = await admin.auth().createUser({
        email: internalEmail,
        password,
        displayName
      });
      createdUid = user.uid;

      await db.batch()
        .set(db.collection("users").doc(user.uid), {
          uid: user.uid,
          username,
          displayName,
          online: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true })
        .set(usernameRef, {
          uid: user.uid,
          displayName,
          reserved: false,
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true })
        .set(passwordRef, {
          uid: user.uid,
          reserved: false,
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true })
        .commit();

      return { ok: true, uid: user.uid, username };
    } catch (err) {
      // Roll back reservations if auth creation failed.
      if (!createdUid) {
        await Promise.allSettled([
          passwordRef.delete(),
          usernameRef.delete()
        ]);
      }

      if (err instanceof HttpsError) throw err;
      if (err?.code === "auth/email-already-exists") {
        throw new HttpsError("already-exists", "USERNAME_ALREADY_USED");
      }
      throw new HttpsError("internal", "REGISTRATION_FAILED");
    }
  }
);
